
namespace WebAPI.Payloads
{
    public class LogicValuePayload
    {
        public double value { get; set; }
        public bool writable { get; set;}
    }
}