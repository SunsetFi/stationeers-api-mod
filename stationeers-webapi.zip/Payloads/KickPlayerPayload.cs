
namespace WebAPI.Payloads
{
    public class KickPlayerPayload
    {
        public string reason { get; set; }
    }
}