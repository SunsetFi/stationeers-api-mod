
namespace WebAPI.Payloads
{
    public class AuthenticateWithSteamPayload
    {
        public string location { get; set; }
    }
}