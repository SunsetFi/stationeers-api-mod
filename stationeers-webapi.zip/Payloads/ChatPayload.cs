
namespace WebAPI.Payloads
{
    public class ChatPayload
    {
        public string displayName { get; set; }
        public string message { get; set; }
    }
}