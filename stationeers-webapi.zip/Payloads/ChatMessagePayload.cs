
namespace WebAPI.Payloads
{
    public class ChatMessagePayload
    {
        public string message { get; set; }
    }
}