
namespace WebAPI.Payloads
{
    public class PostSavePayload
    {
        public string fileName { get; set; }
    }
}