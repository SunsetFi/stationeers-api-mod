
namespace WebAPI.Payloads
{
    public class BanPlayerPayload
    {
        public string reason { get; set; }
        public double hours { get; set; }
    }
}