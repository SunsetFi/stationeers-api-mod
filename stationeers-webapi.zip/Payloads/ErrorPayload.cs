
namespace WebAPI.Payloads
{
    public class ErrorPayload
    {
        public string message;
    }
}